/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
#ifndef COGNITIVE_HELPER_H
#define COGNITIVE_HELPER_H

#include "ns3/cognitive.h"

namespace ns3 {

/* ... */

}

#endif /* COGNITIVE_HELPER_H */

